def decoder():
        
    iFile = open("Encrypted.txt", encoding = "utf8")

    oFile = open("DecryptedCGB.txt", 'w')

    lines  = str(iFile.readlines())

    #lines = ord(chr(lines))

    #print (lines)



    #for line in lines:
    for chr in lines:
        ordinal = ord(chr)

        
                    
        print (ordinal)
        
        
def main():
    decoder()

main()
